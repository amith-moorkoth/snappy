# Changelog


## 1.0.1 (Jan 2, 2016)

- Supports to complete the cropping when dblclick on the crop box.
- Restore the full cropping state after undo cropping.


## 1.0.0 (Jan 1, 2016)

- Supports to upload, move, zoom, rotate, flip and crop an image.
- Keyboard support
